// enemy_b1.js
import { GLOBALS } from '../GameConst.js';
import { GameState } from '../GameState.js';
import { MyMath } from '../utils/MathUtils.js';
import { Enemy } from './enemy.js';

const COOLDOWN_INTERVAL = 50;
const MIN_X = GLOBALS.FIELD.WIDTH * 0.7;

// Enemy_B1：ボス（ステージ１）
export class Enemy_B1 extends Enemy {

    constructor(scene){
        super(scene);
        this.z = GLOBALS.LAYER.LAYER3.Z + 10;
        this.collision = { width :100, height : 300};
        this.scale = 1.0;
        this.life = 160;
        this.speed = 0.3;
        this.shot_count = COOLDOWN_INTERVAL;
        this.score = 3000;
        this.boss = true;
        this.big_explosion = true;
    }

    init(pos){
        super.init(pos);

        // スプライトの設定
        this.sprite = this.scene.add.sprite(this.pos.x, this.pos.y, 'ss_boss_1')
        .setOrigin(0.5, 0.5)
        .setFrame(0);

        // アニメーションの設定
        if (!this.scene.anims.exists("anims_boss_1")) {
            this.scene.anims.create({key: "anims_boss_1",
                frames: this.scene.anims.generateFrameNumbers('ss_boss_1',
                    { start: 0, end: 1}),
                frameRate: 6, repeat: -1
            });
        }
        this.sprite.play("anims_boss_1");
    }

    update(){
        super.update();
        this.velocity = GameState.player.pos.clone().subtract(this.pos).normalize().scale(this.speed * GameState.ff);
        this.pos.add(this.velocity);
        this.pos.x = Math.max(MIN_X, this.pos.x);

        super.update();

        this.shot_count -= GameState.ff;
        if (this.shot_count < 0){
            this.shot_count = COOLDOWN_INTERVAL;
            this.shoot_aim();
            if (GameState.difficulty >= 250){
                this.shoot_aim(-20);
                this.shoot_aim(+20);
            }
        }
    }

    destroy(){
        super.destroy();
    }
}