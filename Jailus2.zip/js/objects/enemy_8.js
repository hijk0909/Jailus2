// enemy_8.js
import { GLOBALS } from '../GameConst.js';
import { GameState } from '../GameState.js';
import { MyMath } from '../utils/MathUtils.js';
import { Enemy } from './enemy.js';

const WAIT_PERIOD = 120;
const GRAVITY = 0.8;
const MAX_DY = 10;
const TILE_SIZE = 32 / MyMath.get_disp_ratio(GLOBALS.LAYER.LAYER3.Z);
const RIGHT_AREA = GLOBALS.FIELD.WIDTH * 0.8;
const COOLDOWN_INTERVAL = 30;
const HORIZONTAL_SPEED = 4;

// Enemy_8：ポップコーン
export class Enemy_8 extends Enemy {

    constructor(scene){
        super(scene);
        this.z = GLOBALS.LAYER.LAYER3.Z;
        this.collision = { width :36, height : 42};
        this.state = 0;
        this.state_count = 80;
        this.dx = 0;
        this.dy = 0;
        this.shot_count = 0;
    }

    init(pos){
        super.init(pos);

        this.move_to_lowest();

        // スプライトの設定
        this.sprite = this.scene.add.sprite(this.pos.x, this.pos.y, 'ss_enemy')
        .setOrigin(0.5, 0.5)
        .setFrame(27);

        // アニメーションの定義
        if (!this.scene.anims.exists("anims_enemy8")) {
            this.scene.anims.create({
                key: "anims_enemy8",
                defaultTextureKey: 'ss_enemy',
                frames: [
                    { frame: 27, duration: 300 },
                    { frame: 29, duration: 30 },
                    { frame: 27, duration: 30 },
                    { frame: 30, duration: 30 },
                    { frame: 27, duration: 30 },
                    { frame: 29, duration: 30 },
                    { frame: 27, duration: 30 },
                    { frame: 30, duration: 30 },
                    { frame: 27, duration: 30 }
                ],
                repeat: -1
            });
        }
    }

    update(){
        super.update();

        if (this.state === 0){
            // 初期状態
            this.pos.x -= GameState.scroll_dx;
            this.dy = 3;
            this.bounded_move();
        } else if (this.state === 1){
            // 待機
            this.pos.x -= GameState.scroll_dx;
            this.state_count -= GameState.ff;
            if (this.state_count <= 0){
                this.state = 2;
                this.sprite.setFrame(27);
                this.sprite.stop();
                this.shot_count = 0;
                this.dy = -20;
                if (this.pos.x > RIGHT_AREA){
                    this.dx = - HORIZONTAL_SPEED;
                } else {
                    this.dx = Math.random() < 0.5 ? -HORIZONTAL_SPEED : +HORIZONTAL_SPEED;
                }
            }
        } else if (this.state === 2){
            // 跳躍
            this.dy = Math.min(MAX_DY, this.dy + GRAVITY * GameState.ff);
            this.bounded_move();
            // 発射
            this.shot_count -= GameState.ff;
            if (this.shot_count < 0){
                this.shot_count = COOLDOWN_INTERVAL;
                this.shoot_aim();
            }
        }
    }

    bounded_move() {
        // ◆X方向の移動
        let nextX = this.pos.x + this.dx * GameState.ff;
        let checkY1 = this.pos.y - this.collision.height / 2 + 1;
        let checkY2 = this.pos.y + this.collision.height / 2 - 1;

        // 移動先の「左右辺の中点」を確認
        if (this.dx > 0) {
            // 右移動 → 右辺を確認
            let checkX = nextX + this.collision.width / 2;
            if (GameState.bg.is_terrain_at_point(checkX, checkY1) || GameState.bg.is_terrain_at_point(checkX, checkY2)) {
                let tileX = Math.floor(checkX / TILE_SIZE);
                nextX = tileX * TILE_SIZE - this.collision.width / 2;
                this.dx *= -1;
            }
        } else if (this.dx < 0) {
            // 左移動 → 左辺を確認
            let checkX = nextX - this.collision.width / 2;
            if (GameState.bg.is_terrain_at_point(checkX, checkY1) || GameState.bg.is_terrain_at_point(checkX, checkY2)){
                let tileX = Math.floor(checkX / TILE_SIZE);
                nextX = (tileX + 1) * TILE_SIZE + this.collision.width / 2;
                this.dx *= -1;
            }
        }
        this.pos.x = nextX;

        // ◆Y方向の移動
        let nextY = this.pos.y + this.dy * GameState.ff;
        let checkX1 = this.pos.x - this.collision.width / 2 + 1;
        let checkX2 = this.pos.x + this.collision.width / 2 - 1;

        if (this.dy > 0) {
            // 下移動 → 下辺を確認
            let checkY = nextY + this.collision.height / 2;
            if (GameState.bg.is_terrain_at_point(checkX1, checkY) || GameState.bg.is_terrain_at_point(checkX2, checkY)){
                // 地面に衝突
                let tileY = Math.floor(checkY / TILE_SIZE);
                nextY = tileY * TILE_SIZE - this.collision.height / 2;
                this.state = 1;
                this.state_count = WAIT_PERIOD;
                this.sprite.setFrame(27);
                this.sprite.play("anims_enemy8");
            }
        } else if (this.dy < 0) {
            // 上移動 → 上辺を確認
            let checkY = nextY - this.collision.height / 2;
            if (GameState.bg.is_terrain_at_point(checkX1, checkY) || GameState.bg.is_terrain_at_point(checkX2, checkY)){
                // 天井に衝突
                let tileY = Math.floor(checkY / TILE_SIZE);
                nextY = (tileY + 1) * TILE_SIZE + this.collision.height / 2;
                this.dx = 0;
                this.state = 0;
                this.sprite.setFrame(28);
                this.sprite.stop();
            }
        }
        this.pos.y = nextY;
    }

    move_to_lowest(){
        for (let y = GLOBALS.FIELD.HEIGHT - TILE_SIZE; y > 0; y -= TILE_SIZE){
            if (!GameState.bg.is_terrain_at_point(this.pos.x, y)){
                this.pos.y = y + this.collision.height / 2;
                break;
            }
        }
    }

    destroy(){
        super.destroy();
    }
}