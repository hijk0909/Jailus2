// enemy_15b.js
import { GLOBALS } from '../GameConst.js';
import { GameState } from '../GameState.js';
import { MyMath } from '../utils/MathUtils.js';
import { Bullet } from './bullet.js';
import { Enemy_15_ } from './enemy_15_.js';
import { spawn_vine, get_vine_pos } from './enemy_15b_spawner.js';
import { Effect_Ext } from './effect_ext.js';

const COOLDOWN_INTERVAL = {
    EASY : 120,
    HARD : 30
}

const SPAWN_INTERVAL_1 = 10;
const SPAWN_INTERVAL_2 = 60;

const STEP_ANGLE = 0.5;
const MAX_ANGLE = 12.5;

// Enemy_15b：植物砲台（蔓）
export class Enemy_15b extends Enemy_15_ {

    constructor(scene){
        super(scene);
        this.shot_count = COOLDOWN_INTERVAL.EASY;
        this.spawn_count = SPAWN_INTERVAL_1;
        this.life = 1;
        this.angle = 0;
        this.max_angle = MAX_ANGLE;
        this.length = 16;
        this.score = 10;
    }

    init(pos){
        super.init(pos);

        // スプライトの設定
        this.sprite = this.scene.add.sprite(this.pos.x, this.pos.y, 'ss_enemy')
        .setOrigin(0.5, 0.5)
        .setFrame(9);
        this.update_position(this.sprite);
        this.update_angle();
    }

    update(){
        this.pos.x -= GameState.scroll_dx;
        this.sprite.angle = this.angle + 90;

        if (!this.child){
            if (this.energy > 0){
                // 先端かつ根と繋がっているなら弾を発射
                this.shot_count -= GameState.ff;
                if (this.shot_count < 0){
                    this.shot_count = MyMath.lerp_by_difficulty(COOLDOWN_INTERVAL.EASY, COOLDOWN_INTERVAL.HARD);
                    this.shoot_fix(this.angle + 90);
                }
            }
            if (this.energy > 1){
                // 先端かつ根と繋がり、かつ余力があれば蔓を伸ばす
                this.spawn_count -= GameState.ff;
                if (this.spawn_count < 0){
                    this.spawn_count = SPAWN_INTERVAL_2;
                    this.child = spawn_vine(this);
                }
            }
        }

        if (this.energy === 0){
            this.alive = false;
            const eff = new Effect_Ext(this.scene);
            eff.init(this.pos);
            GameState.effects.push(eff);            
        } else {
            this.pos = get_vine_pos(this.parent);
            this.update_angle();
        }

        super.update();
    }

    update_angle(){
        this.angle = MyMath.rotate_towards_target(this.angle, this.pos, GameState.player.pos, STEP_ANGLE, this.parent.angle, this.parent.max_angle);
        this.sprite.angle = this.angle + 90;
    }

    destroy(){
        super.destroy();
    }
}