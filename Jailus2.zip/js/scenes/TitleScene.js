// TitleScene.js
import { GameState } from '../GameState.js';
import { GLOBALS } from '../GameConst.js';
import { MyInput } from '../utils/InputUtils.js';

const FONT_SIZE = 16;

export class TitleScene extends Phaser.Scene {
    constructor() {
        super({ key: 'TitleScene' });
        this.stage_data = null;
        this.start_stage = 1;
        this.start_area = 1;
        this.attract_timer = null;
    }

    create() {
        this.stage_data = this.cache.json.get('stage_data');

        // 座標変数
        this.cx = this.game.canvas.width / 2;
        this.cy = this.game.canvas.height / 2;
        this.hy = this.game.canvas.height;

        // 隠しキー
        this.keyF = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.F);
        this.keyG = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.G);
        this.keyV = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.V);
        this.keyB = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.B);
        this.keyA = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
        this.keyC = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.C);

        this.my_input = new MyInput(this);
        this.my_input.registerPadConnect(() => this.show_pad());
        if (this.my_input.pad){this.show_pad();}
        this.my_input.registerNextAction(() => this.start_game());

        
        this.title_logo = this.add.image(this.cx,220,'title').setOrigin(0.5,0.5).setScale(0.45, 0.45);
        // this.add.text(this.cx, 50, 'Jailus 2', { fontSize: '64px', fill: '#ffee00' , stroke: '#ff0000', strokeThickness: 2}).setOrigin(0.5,0.5);
        this.add.text(this.cx, 10, 'Copyright Current Color Co. Ltd. All rights reserved.', { fontSize: '18px', fill: '#888' }).setOrigin(0.5,0);
        this.start_stage_txt = this.add.text(this.cx, this.hy - 155, 'START STAGE: ', { fontSize: '24px', fill: '#eee' }).setOrigin(0.5,0.5).setVisible(false);

        this.add.text(this.cx, this.hy - 125, 'PUSH SPACE KEY',{ fontSize: '24px', fill: '#fff' }).setOrigin(0.5,0.5);
        this.clear_text();
        const ver_text = `VERSION : ${GLOBALS.VERSION}`
        const ver_text_x = (this.game.canvas.width - ver_text.length * FONT_SIZE) / 2;
        this.add_text(ver_text_x,275,ver_text);

        const btn_play = this.add.image(this.cx, this.hy - 10, 'btn_tap')
        .setOrigin(0.5,1)
        .setInteractive()
        .on('pointerdown', () => {this.start_game();})
        .on('pointerover', () => {btn_play.setTint(0xcccccc);})
        .on('pointerout', () => {btn_play.clearTint();});

        this.reset_attract_timer();

        this.add.image(80,300,'op_1').setOrigin(0,0);
        this.add.image(300,300,'op_2').setOrigin(0,0);
        this.add.image(520,300,'op_3').setOrigin(0,0);

        // グリッチシェーダー
        this.glitch_counter = 0;
        this.title_logo.setPipeline('Glitch');
        this.glitch = this.renderer.pipelines.get('Glitch');
        this.glitch.set1i('frame', 0); //スプライトシート（フレーム）は使わない
        this.glitch.set1f('time', 0);
        this.glitch.set1f('uDisplace', 1.0);
        this.glitch.set1f('uHueShift', 0.5);
        this.glitch.set1f('uDesaturate', 0.0);
        this.glitch.set1f('alpha', 1.0);
    }

    reset_attract_timer(){
        // 既存のイベントを止める
        if (this.attract_timer) {
            this.attract_timer.remove(false);
        }

        // 新しく10秒タイマーを作成
        this.attract_timer = this.time.addEvent({
            delay: 10000,
            callback: () => {
                this.scene.start('AttractScene');
            },
            callbackScope: this
        });
    }

    update(time, delta){

        // グリッチシェーダー
        this.glitch_counter += delta;
        this.glitch.set1f('time', time);
        const p = (- Math.cos(this.glitch_counter / 800) + 1) / 16;
        this.glitch.set1f('uDisplace', p);
        this.glitch.set1f('uHueShift', p * 12);
        // this.glitch.set1f('uDesaturate', p);

        // 隠しキー操作
        if (GameState.debug_key){
            if (Phaser.Input.Keyboard.JustDown(this.keyF)){
                this.start_stage = Math.max(1, this.start_stage - 1);
                this.start_area = 1;
                this.show_start_stage();
            }
            if (Phaser.Input.Keyboard.JustDown(this.keyG)){
                this.start_stage = Math.min(GLOBALS.STAGE_MAX, this.start_stage + 1);
                this.start_area = 1;
                this.show_start_stage();
            }
            if (Phaser.Input.Keyboard.JustDown(this.keyV)){
                this.start_area = Math.max(1, this.start_area - 1);
                this.show_start_stage();
            }
            if (Phaser.Input.Keyboard.JustDown(this.keyB)){
                const stage_info = this.stage_data.stages.find(s => s.stage === this.start_stage);
                this.start_area = Math.min(stage_info.areas.length, this.start_area + 1);
                this.show_start_stage();
            }
            if (Phaser.Input.Keyboard.JustDown(this.keyA)){
                this.scene.start('AttractScene');
            }
            if (Phaser.Input.Keyboard.JustDown(this.keyC)){
                this.scene.start('GameClearScene');
            }
        }
    }
    show_start_stage(){
        this.start_stage_txt.setText(`START STAGE : ${this.start_stage} - ${this.start_area}`).setVisible(true);
    }

    show_pad(){
        this.add.text(this.cx, this.hy - 100, ' or PRESS START BUTTON',{ fontSize: '24px', fill: '#fff' }).setOrigin(0.5, 0.5);
    }

    add_text(x,y,text){
        this.add.bitmapText(x, y, 'myFont', text, FONT_SIZE)
        .setName('titleText');        
    }
    clear_text(){
        this.children.getAll().forEach(child => {
            if (child.name === 'titleText') {
                child.destroy();
            }
        });
    }

    start_game(){
        // 念のため、各シーンを止める
        // → 1フレーム内で start/stop すると競合が発生し得るので削除
        // this.scene.stop('GameScene');
        // this.scene.stop('GameOverScene');
        // this.scene.stop('GameClearScene');
        // this.scene.stop('NameEntryScene');
        // this.scene.stop('UI');

        // GameState.sound.se_tap.play();
        GameState.reset();
        GameState.stage = this.start_stage;
        GameState.area = this.start_area;
        this.scene.start('GameScene');
    }
}
